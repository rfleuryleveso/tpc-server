# Manuel d'utilisation du serveur

### Commande installation node_modules

`
npm install
`

### Lancer le server

`
npm run build-start
`